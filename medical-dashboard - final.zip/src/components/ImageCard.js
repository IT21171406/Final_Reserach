import React from 'react';

const ImageCard = ({ imageUrl, cardName, icon, numbers }) => {
  return (
    <div className="card">
      <div>
        {numbers && <div className="numbers" style={{
          fontWeight: '600',
          fontSize: '2em',
          color: '#2a3f54'
        }}>{numbers}</div>}
        <div className="cardName">{cardName}</div>
      </div>
      
      <div className="iconBx" style={{
        fontSize: '3.5em',
        color: '#2a3f54',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center'
      }}>
        {imageUrl ? (
          <img 
            src={imageUrl} 
            alt={cardName} 
            style={{
              width: '60px',
              height: '60px',
              borderRadius: '10px',
              objectFit: 'cover',
              marginBottom: '10px'
            }}
          />
        ) : (
          <ion-icon name={icon}></ion-icon>
        )}
      </div>
    </div>
  );
};

export default ImageCard;