const ENV = {
    SERVER: 'http://localhost:8000',
    PORT: '8000'

}

export default ENV